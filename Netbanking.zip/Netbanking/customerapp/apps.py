from django.apps import AppConfig


class CustomerappConfig(AppConfig):
    name = 'customerapp'
